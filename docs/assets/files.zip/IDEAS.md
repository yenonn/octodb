# OctoDB — Ideas & Scratchpad

A running dump of raw thoughts, open questions, and future directions. Not everything here will ship. That's fine.

---

## Open Questions

### Data Model
- How do we handle OTLP schema evolution? The opentelemetry-proto spec changes — our storage schema needs a versioning strategy.
- What's the right granularity for resource deduplication? Per ingestion batch? Per time window? Global dedup table?
- How do we store sparse attributes efficiently? OTel resource attributes are open-ended — cardinality can explode.
- Should we store raw OTLP bytes alongside the structured model? Useful for replay and debugging but doubles storage.

### Multi-Tenancy
- What happens when a resource has no resolvable tenant attributes? Silent drop? Default tenant? Alert?
- How do we handle tenant migration — moving historical data from one tenant partition to another?
- Should tenants have storage quotas? Ingestion rate limits? How are these enforced?
- Cross-tenant exemplar linking — if a trace crosses tenant boundaries (service mesh call between teams), how do we handle exemplar links that reference spans in a different tenant?

### ACL
- How do we audit ACL evaluations? Every query against sensitive signal data should be logged.
- How do we handle ACL hot reload — changing permissions without restarting the database?
- Should ACL rules be stored inside OctoDB itself or in an external config file? External config is simpler, internal storage is more dynamic.
- OPA/Cedar integration as a future ACL backend — keep the interface clean enough to plug in.

### Query
- What does "trace reconstruction" look like as a query? SELECT * FROM traces WHERE trace_id = X is too simple — you want the full span tree.
- How do we expose service graph topology? The relationship between services is implicit in parent_span_id chains — can we materialize this as a queryable graph?
- Time-series downsampling for long retention — how do we age out high-resolution metrics into lower-resolution aggregates without losing exemplar links?

### Storage Engine
- Bε-tree vs LSM vs ART — need to benchmark against real OTel query patterns before deciding.
- WAL format — should it be OTLP binary directly, or a custom internal format? OTLP binary WAL enables native replay but may be less compact.
- Columnar storage for metrics — metrics are naturally columnar (many datapoints, same schema). Traces are naturally row/tree. Should we have hybrid storage?
- Memory-mapped files for hot data — relevant for low-latency trace lookup.

### Operational
- How does OctoDB cluster? Single-node first, but clustering design should not be an afterthought.
- What's the compaction strategy? LSM-style compaction, or something else?
- How do we expose OctoDB's own health as OTel signals? Dogfooding — OctoDB should be its own first user.

---

## Future Feature Ideas

### OctoDB as a Collector Replacement
If OctoDB natively speaks OTLP and handles routing internally, it could replace the OTel Collector entirely for many pipelines. An embedded processor pipeline (filter, transform, sample) inside OctoDB would make this viable. Lower operational surface for the end user.

### Adaptive Sampling at Ingestion
Tail-based sampling is hard because you need to see the full trace before deciding whether to keep it. OctoDB sees the full trace — it could make tail-based sampling decisions at write time, after all spans arrive, before committing to long-term storage. This would be a significant differentiator over collector-level sampling.

### Service Graph Materialization
Materialize the service dependency graph from trace parent/child relationships in real time. Query: "show me all services that call payment-service and their error rates." This is possible today with Tempo + Prometheus but requires two systems. OctoDB could serve this from a single query.

### Exemplar-Native Alerting
If OctoDB knows which metric datapoints have exemplar links to traces, it could surface the relevant trace automatically when an alert fires. "Your p99 latency just exceeded threshold — here is the trace that caused it." No cross-system correlation needed.

### OTLP-over-WebSocket for Browser Agents
Browser-based OTel SDKs can't use gRPC easily. An OctoDB WebSocket ingestion endpoint that speaks OTLP-JSON would enable frontend observability data to land directly in OctoDB without a collector proxy.

### Time-Travel Queries
Immutable storage + WAL replay = time-travel queries are theoretically possible. "Show me the service graph as it looked at 14:32 yesterday." Useful for incident reconstruction.

### Federated OctoDB
Multiple OctoDB instances (per region, per cluster) with a federation layer that makes cross-region queries feel like a single system. Octoroute handles the network routing between them naturally.

### OctoDB + Octoroute Integration
Octoroute does mTLS cert-based routing at the network layer. OctoDB does cert-based tenant routing at the data layer. Deep integration: Octoroute could inject tenant context headers at the network layer that OctoDB trusts natively, eliminating duplicate auth. Zero-trust end-to-end.

---

## Technology Notes

### Rust Crates to Evaluate
- `opentelemetry-proto` — Rust bindings for OTLP protobuf
- `tonic` — gRPC server for OTLP ingestion endpoint
- `tokio` — async runtime
- `arrow-rs` — columnar data for metrics storage
- `object_store` — S3/GCS/Azure Blob backend for cold storage
- `fjall` — Rust LSM storage engine (study internals)
- `sled` — embedded Rust database (study internals, mostly abandoned but educational)

### Go Libraries for Prototype
- `go.opentelemetry.io/proto/otlp` — OTLP protobuf definitions
- `google.golang.org/grpc` — gRPC server
- `modernc.org/sqlite` — pure Go SQLite (no CGo, easier cross-compilation)
- `github.com/marcboeker/go-duckdb` — DuckDB for columnar prototype storage

### Papers to Read
- "The Bw-Tree: A B-tree for New Hardware" — Microsoft Research
- "Designing Access Methods: The RUM Conjecture" — Harvard
- "The Case for Learned Index Structures" — Google Brain
- "COLA: Cache-Oblivious Lookahead Arrays" — MIT
- "Anna: A KVS For Any Scale" — Berkeley

---

## Naming & Branding Notes

**Name:** OctoDB  
**Platform family:** Octo (Octoroute + OctoDB)  
**Tagline:** *OTLP is the schema, not the input format*

**Logo direction:**
- Avoid literal cartoon octopus
- Eight arms as abstract data flows converging into one storage core
- Geometric, clean, infrastructure-aesthetic
- Color: deep teal or slate — close to OTel's blue but distinct

**Domain ideas:**
- octodb.io
- octodb.dev
- getoctodb.io

---

## Inspiration Projects to Study

| Project | Language | What to Learn |
|---------|----------|---------------|
| TigerBeetle | Zig | Storage engine design, financial-grade correctness |
| RisingWave | Rust | Streaming SQL, Rust async patterns at scale |
| Databend | Rust | Cloud-native warehouse, columnar storage in Rust |
| Neon | Rust | Postgres storage layer separation |
| ClickHouse | C++ | Columnar storage, vectorized execution |
| Prometheus TSDB | Go | Time-series storage, chunk encoding |
| Grafana Tempo | Go | Trace storage, Parquet backend |

---

## Session Log

### 2026-04-18 — Founding Session
- Problem statement defined: OTel backends treat OTLP as input format, not schema
- Core thesis: eliminate routing layer, make OTLP the schema
- Multi-tenancy model: dynamic tenant resolution from resource attributes
- ACL model: ABAC expressed in OTel vocabulary
- mTLS as primary auth — consistent with Octoroute
- Kafka replaced by internal WAL; NATS considered as alternative
- Implementation path: Go prototype → storage design → Rust core
- Named: **OctoDB**
- Platform family: **Octo** (Octoroute + OctoDB)
