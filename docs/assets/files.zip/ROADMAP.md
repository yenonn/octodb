# OctoDB — Roadmap

A rough phased roadmap. Dates are intentionally loose — this is a side project built around a full-time engineering role.

---

## Phase 0 — Foundation (Now)
**Goal:** Get the project scaffolded and the design documented clearly enough to return to after interruptions.

- [x] Define problem statement
- [x] Define core architecture
- [x] Define multi-tenancy model
- [x] Define ACL model
- [x] Choose name (OctoDB)
- [x] Create project documentation (README, ADR, IDEAS)
- [ ] Create GitHub repository (public or private)
- [ ] Register domain (octodb.io / octodb.dev)
- [ ] Write the public thesis post — "Why OctoDB needs to exist"

---

## Phase 1 — Go Prototype
**Goal:** Prove the data model and ACL design work against real OTel data. A working system, not a production system.

### Ingestion
- [ ] OTLP gRPC receiver (traces, metrics, logs)
- [ ] Tenant resolution from resource attributes
- [ ] Configurable tenant resolution policy (YAML)
- [ ] Basic token auth (mTLS deferred to Phase 3)

### Storage (Prototype-grade)
- [ ] SQLite or DuckDB backing store
- [ ] Resource deduplication table
- [ ] Span storage with parent_span_id relationship preserved
- [ ] Metric datapoint storage with resource foreign key
- [ ] Log record storage with trace context linking
- [ ] Exemplar storage with metric ↔ trace link

### ACL
- [ ] Principal definition (YAML config)
- [ ] Signal-type permission (read/write per signal)
- [ ] Resource attribute predicate evaluation
- [ ] Cross-tenant read permission

### Query API
- [ ] HTTP/REST JSON query API
- [ ] Get trace by trace_id (full span tree)
- [ ] Get metrics by resource attribute filter + time range
- [ ] Get logs by resource attribute filter + time range
- [ ] Get exemplars for a metric datapoint

### Validation
- [ ] Send real OTel data from a test application
- [ ] Validate tenant routing works correctly
- [ ] Validate ACL enforcement works correctly
- [ ] Document query patterns observed — feeds Phase 2 storage design

---

## Phase 2 — Storage Design
**Goal:** Design the production storage engine based on real query patterns from Phase 1.

- [ ] Benchmark query patterns from Phase 1 prototype
- [ ] Evaluate data structures: Bε-tree vs ART vs hybrid
- [ ] Design WAL format
- [ ] Design columnar layout for metrics
- [ ] Design tree structure for traces
- [ ] Design resource deduplication strategy at scale
- [ ] Design compaction strategy
- [ ] Write storage engine specification document

---

## Phase 3 — Rust Core
**Goal:** Rewrite storage engine in Rust. Go prototype remains as correctness reference and query layer until full migration.

- [ ] OTLP gRPC ingestion in Rust (tonic)
- [ ] WAL implementation in Rust
- [ ] Storage engine implementation (data structures from Phase 2)
- [ ] mTLS ingestion auth (certificate → tenant identity)
- [ ] ACL engine in Rust
- [ ] Query layer in Rust
- [ ] Correctness validation against Go prototype
- [ ] Benchmarking vs ClickHouse, Prometheus TSDB, Grafana Tempo

---

## Phase 4 — Open Source + Consulting
**Goal:** Release publicly, build reputation, generate consulting opportunities.

- [ ] Open source core under permissive license (Apache 2.0 or MIT)
- [ ] Documentation site
- [ ] Helm chart for Kubernetes deployment
- [ ] Integration guides: replace Prometheus, replace Jaeger, replace Loki
- [ ] Blog series: "Building OctoDB" — architecture decisions, lessons learned
- [ ] Conference talk proposals: KubeCon, OTel community day, FOSDEM
- [ ] Consulting offering: OctoDB deployment, migration from existing stack, custom signal pipeline design

---

## Non-Goals (Explicitly Out of Scope for Now)

- Distributed/clustered mode — single node first
- Custom query language — HTTP API first, language layer later
- UI/dashboard — integrate with Grafana via data source plugin, don't build a frontend
- ML/AI features — focus on storage and query correctness first
- Multi-region federation — Octoroute handles this at the network layer
